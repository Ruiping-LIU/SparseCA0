#' Title Return the weighted Variance
#'
#' @param vec
#' @param W MatrixWeight
#'
#' @return weighted variance
#' @export
#'
#' @examples
weight.var <- function(vec, W){
  return(t(vec)%*%W%*%vec)
}
