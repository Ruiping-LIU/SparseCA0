#' Title Return the svd results for SCA by BiOPD
#'
#' @param X Frequency data
#' @param para.pmd parameter range for 'tau' type
#' @param para.uv parameter range for 'grid' type
#' @param v0 the initial v
#' @param cK For Criterion=='Nonzeros'
#' @param Sparse.type tau or grid
#' @param decomposition.type BiOPD'
#' @param Criterion.type default=IS'
#'
#' @return BiOPD results
#' @export
#'
#' @examples SCApmd

SCApmd <- function(
  X, para.pmd, para.uv,
  v0,
  cK,
  Sparse.type,
  decomposition.type,
  Criterion.type){
  if (Sparse.type == 'tau'){
    # Dim1
    res.pmd.dim1 <- NULL;
    res.pmd.sumabs.dim1 <- NULL;
    for (i in 1:length(para.pmd)){
      res.pmd.sumabs.dim1[[i]] <- PMD(Yn1, type="standard",
                                      sumabs=para.pmd[i],
                                      sumabsu=NULL, sumabsv=NULL, lambda=NULL,
                                      niter=20, K=1, #K=min(dim(Yn1))
                                      v=v0, trace=F, #
                                      center=F, chrom=NULL, rnames=NULL, cnames=NULL,
                                      upos=FALSE,
                                      uneg=FALSE, vpos=FALSE, vneg=FALSE)
    }
    res.pmd.dim1 = res.pmd.sumabs.dim1
  }
  else if (Sparse.type == 'grid'){ # (sumabsu, sumabsv)
    luv = dim(para.uv)[1];
    # Dim1
    res.pmd.sumabsuv.dim1 <- NULL; #len=lu*lv
    for (i in 1:luv){
      res.pmd.sumabsuv.dim1 <- c(res.pmd.sumabsuv.dim1,
                                 list(PMD(Yn1, type="standard",sumabs=NULL,
                                          sumabsu=
                                            para.uv[i, 1],
                                          sumabsv=
                                            para.uv[i, 2],
                                          lambda=NULL,
                                          niter=20, K=1,
                                          v=v0[,1], # NULL,
                                          trace=F,
                                          center=F, chrom=NULL, rnames=NULL, cnames=NULL, upos=FALSE,
                                          uneg=FALSE, vpos=FALSE, vneg=FALSE))
      )
    }
    res.pmd.dim1 <- res.pmd.sumabsuv.dim1
  }
  # Dim2
  temp.Criterion.dim1 <-
    Decomposition.Criterion.Dim1(Fd = X,
                                 Yn1,
                                 v0,
                                 Dn, Dp,
                                 re = re.CA,
                                 para.pmd,
                                 para.uv,
                                 cK,
                                 Sparse.type,
                                 Criterion.type,
                                 decomposition.type,
                                 res.pmd.dim1);
  i0.dim1 <- temp.Criterion.dim1$i0.dim1
  # Criterion.Dim2
  Criterion.BiOPD.dim2 <-
    Decomposition.Criterion.Dim2(Fd = X,
                                 Yn1, v0,
                                 Dn, Dp,
                                 re = re.CA,
                                 cK,
                                 Sparse.type,
                                 Criterion.type,
                                 decomposition.type,
                                 temp.Decomposition.dim1 = temp.Criterion.dim1);
  i0.dim2 <- Criterion.BiOPD.dim2$i0.dim2;
  # i0.dim2.union <- Criterion.BiOPD.dim2$i0.dim2.union
  #PEV
  PEV <- NULL;
  PEV$PEV0 <- c(res.pmd.dim1[[i0.dim1]]$d^2,
                temp.Criterion.dim1$res.BiOPD.dim2[[i0.dim2]]$d^2)/sum(re.CA$eig[,1]);
  # PEV$PEV.union <- c(res.pmd.dim1[[i0.dim1]]$d^2,
  #                    temp.Criterion.dim1$res.BiOPD.dim2[[i0.dim2.union]]$d^2)/sum(re$eig[,1])
  list(
    res.pmd.dim1 = res.pmd.dim1,
    temp.Criterion.dim1 = temp.Criterion.dim1,
    res.pmd.dim2 = temp.Criterion.dim1$res.pmd.dim2,
    res.BiOPD.dim2 = temp.Criterion.dim1$res.BiOPD.dim2,
    Criterion.BiOPD = Criterion.BiOPD.dim2,
    PEV = PEV
  )
}
